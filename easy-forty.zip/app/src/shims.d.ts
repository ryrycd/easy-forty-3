declare const APP_VERSION: string;
