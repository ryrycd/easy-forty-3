Easy Forty - Cloudflare Pages + Telnyx

This repository is deployed to Cloudflare Pages with Functions, D1 (SQLite) and R2 (object storage). It powers a mobile-first Typeform-like flow, a Telnyx SMS/MMS conversation, and an admin panel for rotating Acorns referral links.

See deployment instructions in the project deliverable message.
